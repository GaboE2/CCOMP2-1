#pragma once
#include <iostream>

void ingresarfila(int&);
void ingresarcolumna(int&);
void ingresarfigura(char&);
void ingresarvalores(int& , int& , char& , bool , bool );

