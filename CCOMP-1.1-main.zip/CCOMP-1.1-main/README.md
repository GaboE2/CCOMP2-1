# CCOMP-1.1

// https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797
// ahi se encuentra la tipografía y los colores.
